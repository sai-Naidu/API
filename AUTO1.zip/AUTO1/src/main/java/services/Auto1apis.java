package services;

/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as Base for all APIs
 */

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Auto1apis {

	public static Response getManufaturers(String URI, String P1,String P1_V, 
			String P2, String P2_V){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.queryParam(P1, P1_V);
		requestSpecification.queryParam(P2, P2_V);
		Response response = requestSpecification.get(URI);
		return response;
	}
	
	public static Response getMainTypes(String URI, String P1,String P1_V, 
			String P2, String P2_V,String P3, String P3_V){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.queryParam(P1, P1_V);
		requestSpecification.queryParam(P2, P2_V);
		requestSpecification.queryParam(P3, P3_V);
		Response response = requestSpecification.get(URI);
		return response;
	}
	
	public static Response getBuiltDates(String URI, String P1,String P1_V, 
			String P2, String P2_V,String P3, String P3_V,String P4, String P4_V){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.queryParam(P1, P1_V);
		requestSpecification.queryParam(P2, P2_V);
		requestSpecification.queryParam(P3, P3_V);
		requestSpecification.queryParam(P4, P4_V);
		Response response = requestSpecification.get(URI);
		return response;
	}
	
	/*
	 * 
	 * This is a dummy method 
	 */
	public static Response extraParam(String URI, String P1,String P1_V, 
			String P2, String P2_V,String P3, String P3_V,String P4, String P4_V,String P5,String P5_V){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.queryParam(P1, P1_V);
		requestSpecification.queryParam(P2, P2_V);
		requestSpecification.queryParam(P3, P3_V);
		requestSpecification.queryParam(P4, P4_V);
		requestSpecification.queryParam(P5, P5_V);
		Response response = requestSpecification.get(URI);
		return response;
	}
}
