package dataRepository;


/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as data source for Built-dates API
 */
public class BuiltDatesData extends CommonData {
	
	public String URI = BaseURI+Resource3;
	
	//data of main-type -Alfa 145
	public String Param3_val_Alfa_145 = "040";
	public String Param4_val_Alfa_145 = "Alfa 145";
	public String sheetName_Alfa_145 = "BuiltDates_Alfa 145";
	public int countOfBuiltDates_Alfa_145 = 8;
	public int Keys_Alfa_145 = 8;
	public int Values_Alfa_145 = 8;
	
	

}
