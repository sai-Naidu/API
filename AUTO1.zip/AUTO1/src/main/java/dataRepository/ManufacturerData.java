package dataRepository;

/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as data source for manufacturer API
 */


public class ManufacturerData extends CommonData {
	
	public String URI = BaseURI+Resource1;
	public String fileName_Manufacturer= "Manufacturer.xlsx";
	public String sheetName_Manufacturer= "Manufacturers";
	public int countOfManufacturers = 72;
	public int manufacturerkeys = 72;
	public int manufacturerValues = 72;

}
