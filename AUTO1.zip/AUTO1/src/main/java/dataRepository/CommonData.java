package dataRepository;

/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as common data source for all APIs
 */

public class CommonData {
	
	//URI and Resources
	public String BaseURI = "http://api-aws-eu-qa-1.auto1-test.com";
	public String Resource1 = "/v1/car-types/manufacturer";
	public String Resource2 = "/v1/car-types/main-types";
	public String Resource3 = "/v1/car-types/built-dates";
	
	//Parameters and Values
	public String Param1 = "locale";
	public String Param2 = "wa_key";
	public String Param3 = "manufacturer";
	public String Param4 = "main-type";
	public String Param1_val = "en";
	public String Param2_val = "coding-puzzle-client-449cc9d";
	
	//status codes
	public int statusCode_OK = 200;
	public int statusCode_Bad_Request = 400;
	public int statusCode_Unauthorized = 401;
	public int statusCode_Forbidden = 403;
	public int statusCode_Not_Found = 404;
	
	//status lines
	public String statusLine_200 = "HTTP/1.1 200 OK";
	public String statusLine_400 = "HTTP/1.1 400 Bad Request";;
	public String statusLine_401 = "HTTP/1.1 401 Unauthorized";
	public String statusLine_403 = "HTTP/1.1 403 Forbidden";
	public String statusLine_404 = "HTTP/1.1 404 Not Found";
	
	//content type
	public String contentType_expected = "application/json;charset=UTF-8";
	
	//Errors and Exceptions under 400 Bad Request
	public String error_400 = "Bad Request";
	public String message_400_manufacturer = "Required String parameter 'manufacturer' is not present";
	public String message_400_mainType = "Required String parameter 'main-type' is not present";
	public String exception_400 = "org.springframework.web.bind.MissingServletRequestParameterException";
	
	//page details
	public int page_expected = 0;
	public int pageSize_expected = 2147483647;
	public int totalPageCount_expected = 1;
	public int totalPageCount_invalid_expected = 0;
	public String URI = BaseURI+Resource2;
	public String fileName_Maintypes= "MainTypes.xlsx";
	public String fileName_BuiltDates= "BuiltDates.xlsx";
	
	

}
