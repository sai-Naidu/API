package dataRepository;

/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as data source for main-type API
 */

public class MainTypesData extends CommonData {
	
	public String URI = BaseURI+Resource2;
		
	//data of manufacturer - 040
	public String Param3_Val_040 = "040";
	public String sheetName_040 = "Models_040";
	public int countOfMOdels_040 = 25;
	public int Keys_040 = 25;
	public int Values_040 = 25;
	

}
