package testCases;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.testng.Assert;
import org.testng.annotations.Test;
import dataRepository.ManufacturerData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import services.Auto1apis;
import utilities.ReadDataFromExcel;


/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as test  suite for Manufacturer API
 */
public class Test_Manufacturer extends ManufacturerData  {
	
	Response response;
	
	@Test(priority=1)
	public void testManufacturer_With_validParameters() throws IOException {
		
		response = Auto1apis.getManufaturers(URI,Param1,Param1_val,Param2,Param2_val);
		JsonPath jp = response.jsonPath();
		Map<String, String> manufacturers = response.then().extract().path("wkda");
		Set<String> expectedKeys = ReadDataFromExcel.readExcel(fileName_Manufacturer, sheetName_Manufacturer, 0) ;
		Set<String> expectedValues = ReadDataFromExcel.readExcel(fileName_Manufacturer, sheetName_Manufacturer, 1) ;
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_OK);
		
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_200);
		
		//header - contentType
		String contentType = response.getContentType();
		Assert.assertEquals(contentType, contentType_expected);
		
		//page values
		int page = jp.getInt("page");
		int pageSize = jp.getInt("pageSize");
		int totalPageCount = jp.getInt("totalPageCount");
		Assert.assertEquals(page, page_expected);
		Assert.assertEquals(pageSize, pageSize_expected);
		Assert.assertEquals(totalPageCount, totalPageCount_expected);
		
		//manufacturers codes
		int totalManufacturers = manufacturers.size();
		int totalManufacturerKeys = manufacturers.keySet().size();
		int totalManufacturerValues = manufacturers.values().size();
		Assert.assertEquals(totalManufacturers, countOfManufacturers);
		Assert.assertEquals(totalManufacturerKeys, manufacturerkeys);
		Assert.assertEquals(totalManufacturerValues, manufacturerValues);
		
		// manufactures keys and values comparison
		Set<String> actualKeys = manufacturers.keySet();
		Set<String> actualValues = new HashSet<String>(manufacturers.values());
		Assert.assertEquals(actualKeys, expectedKeys);
		Assert.assertEquals(actualValues, expectedValues);	
		
	}
	
	@Test(priority=1)
	public void testManufacturer_Validate_Keys_and_Values_inResposeJSON() {
		
		response = Auto1apis.getManufaturers(URI,Param1,Param1_val,Param2,Param2_val);
		Map<String, String> manufacturers = response.then().extract().path("wkda");
		Assert.assertEquals(manufacturers.get("107"), "Bentley");
		Assert.assertEquals(manufacturers.get("230"), "Dodge");
		Assert.assertEquals(manufacturers.get("362"), "Isuzu");
		Assert.assertEquals(manufacturers.get("470"), "Lancia");
		Assert.assertEquals(manufacturers.get("710"), "Porsche");
		
	}
	
	@Test(priority=2)
	public void testManufacturer_With_invalidParameterName_wa_key()  {
		
		/*
		 * wa_key is replaced with aa_key
		 */
		response = Auto1apis.getManufaturers(URI,Param1,Param1_val,"aa_key",Param2_val);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Unauthorized);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_401);
		
	}
	
	@Test(priority=3)
	public void testManufacturer_With_invalidParameterValue_wa_key()  {
		
		/*
		 * invalid parameter value is used for wa_key
		 */
		response = Auto1apis.getManufaturers(URI,Param1,Param1_val,Param2,"abcd");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Forbidden);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_403);
		
	}
	
	@Test(priority=4)
	public void testManufacturer_With_invalidParameterName_locale()  {
		
		/*
		 * locale is replaced with language
		 */
		response = Auto1apis.getManufaturers(URI,"langauge",Param1_val,Param2,Param2_val);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Bad_Request);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_400);
		
	}
	
	@Test(priority=5)
	public void testManufacturer_With_invalidParameterValue_locale()  {
		
		/*
		 * invalid parameter value is used for locale
		 */
		response = Auto1apis.getManufaturers(URI,Param1,"xyz",Param2,Param2_val);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Not_Found);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_404);
	
	}
	
	@Test(priority=6)
	public void testManufacturer_With_allInvalidParameters()  {
		
		/*
		 * invalid parameters are provided manufacturer URI
		 */
		response = Auto1apis.getManufaturers(URI,"language","english","aa_key","abcd");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Unauthorized);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_401);
		
	}
	
	@Test(priority=7)
	public void testManufacturer_With_extraParameter()  {
		
		/*
		 * main-type method is used to test this. But URI is pointing to Manufacturer 
		 */
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,Param2_val, "extraParam", "extraParam_val");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Bad_Request);
						
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_400);
		
	}
	
	

}
