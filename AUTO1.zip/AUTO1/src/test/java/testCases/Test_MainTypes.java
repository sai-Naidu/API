package testCases;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import dataRepository.MainTypesData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import services.Auto1apis;
import utilities.MultipleDataProvider;
import utilities.ReadDataFromExcel;

/*
 * Written by Hema Sundar Sai
 * 
 * This class will act as test  suite for main-type API
 */

public class Test_MainTypes extends MainTypesData {
	
Response response;
	
	@Test(priority=1)
	public void testMaintypes_With_validParameters() throws IOException {
		
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,Param2_val, Param3, Param3_Val_040);
		JsonPath jp = response.jsonPath();
		Map<String, String> models = response.then().extract().path("wkda");
		Set<String> expectedKeys = ReadDataFromExcel.readExcel(fileName_Maintypes, sheetName_040, 0) ;
		Set<String> expectedValues = ReadDataFromExcel.readExcel(fileName_Maintypes, sheetName_040, 1) ;
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_OK);
		
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_200);
		
		//header - contentType
		String contentType = response.getContentType();
		Assert.assertEquals(contentType, contentType_expected);
		
		//page values
		int page = jp.getInt("page");
		int pageSize = jp.getInt("pageSize");
		int totalPageCount = jp.getInt("totalPageCount");
		Assert.assertEquals(page, page_expected);
		Assert.assertEquals(pageSize, pageSize_expected);
		Assert.assertEquals(totalPageCount, totalPageCount_expected);
		
		//models 
		int totalModels = models.size();
		int totalModelsKeys = models.keySet().size();
		int totalModelsValues = models.values().size();
		Assert.assertEquals(totalModels, countOfMOdels_040);
		Assert.assertEquals(totalModelsKeys, Keys_040);
		Assert.assertEquals(totalModelsValues, Values_040);
		
		// models keys and values comparison
		Set<String> actualKeys = models.keySet();
		Set<String> actualValues = new HashSet<String>(models.values());
		Assert.assertEquals(actualKeys, expectedKeys);
		Assert.assertEquals(actualValues, expectedValues);			
	}
	
	@Test(priority=2)
	public void testMaintypes_With_invalidParameterName_manufacturer()  {
		
		/*
		 * maker is replaced with manufacturer
		 */
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,Param2_val, "maker", Param3_Val_040);
		JsonPath jp = response.jsonPath();
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Bad_Request);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_400);
		
		//error , message and exception
		String error = jp.getString("error");
		String message = jp.getString("message");
		String exception = jp.getString("exception");
		Assert.assertEquals(error, error_400);
		Assert.assertEquals(message, message_400_manufacturer);
		Assert.assertEquals(exception, exception_400);
		
	}
	
	@Test(priority=3)
	public void testMaintypes_With_invalidParameterValue_manufacturer()  {
		
		/*
		 * invalid parameter value is used for manufacturer
		 */
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,Param2_val, Param3, "100");
		JsonPath jp = response.jsonPath();
		Map<String, String> models = response.then().extract().path("wkda");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_OK);
		
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_200);
		
		//header - contentType
		String contentType = response.getContentType();
		Assert.assertEquals(contentType, contentType_expected);
		
		//page values
		int page = jp.getInt("page");
		int pageSize = jp.getInt("pageSize");
		int totalPageCount = jp.getInt("totalPageCount");
		Assert.assertEquals(page, page_expected);
		Assert.assertEquals(pageSize, pageSize_expected);
		Assert.assertEquals(totalPageCount, totalPageCount_invalid_expected);
		
		//models
		int totalModels = models.size();
		int totalModelsKeys = models.keySet().size();
		int totalModelsValues = models.values().size();
		Assert.assertEquals(totalModels, 0);
		Assert.assertEquals(totalModelsKeys, 0);
		Assert.assertEquals(totalModelsValues, 0);	
	}
	
	@Test(priority=4)
	public void testMainTypes_With_invalidParameterName_wa_key()  {
		
		/*
		 * wa_key is replaced with aa_key
		 */
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,"aa_key",Param2_val ,Param3, Param3_Val_040);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Unauthorized);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_401);
		
	}
	
	@Test(priority=5)
	public void testMainTypes_With_invalidParameterValue_wa_key()  {
		
		/*
		 * invalid parameter value is used for wa_key
		 */
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,"abcd", Param3, Param3_Val_040);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Forbidden);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_403);
		
	}
	
	@Test(priority=6)
	public void testMainTypes_With_invalidParameterName_locale()  {
		
		/*
		 * locale is replaced with language
		 */
		response = Auto1apis.getMainTypes(URI,"langauge",Param1_val,Param2,Param2_val,Param3, Param3_Val_040);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Bad_Request);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_400);
		
	}
	
	@Test(priority=7)
	public void testMainTypes_With_invalidParameterValue_locale()  {
		
		/*
		 * invalid parameter value is used for locale
		 */
		response = Auto1apis.getMainTypes(URI,Param1,"xyz",Param2,Param2_val,Param3, Param3_Val_040);
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Not_Found);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_404);
	
	}
	
	@Test(priority=8)
	public void testMainTypes_With_allInvalidParameters()  {
		
		/*
		 * invalid parameters are provided 
		 */
		response = Auto1apis.getMainTypes(URI,"language","english","aa_key","abcd","maker","1000");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Unauthorized);
				
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_401);
		
	}
	
	@Test(priority=9)
	public void testMainTypes_With_extraParameter()  {
		
		/*
		 * built-date method is used to test this. But URI is pointing to main-type
		 */
		response = Auto1apis.getBuiltDates(URI,Param1,Param1_val,Param2,Param2_val,Param3, Param3_Val_040, "extraParam", "extraParam_val");
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_Bad_Request);
						
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_400);
		
	}
	
	/*
	 * This test case is designed to run with multiple data 
	 * We can do data driven testing with this approach
	 */
	@Test(dataProvider = "MainTypesData",priority=10)
	public void testMaintypes_With_validParameters(String param3val, String sheetName,
			String countOfModels, String keys, String values) throws IOException {
		
		response = Auto1apis.getMainTypes(URI,Param1,Param1_val,Param2,Param2_val, Param3, param3val);
		JsonPath jp = response.jsonPath();
		Map<String, String> models = response.then().extract().path("wkda");
		Set<String> expectedKeys = ReadDataFromExcel.readExcel(fileName_Maintypes, sheetName, 0) ;
		Set<String> expectedValues = ReadDataFromExcel.readExcel(fileName_Maintypes, sheetName, 1) ;
		
		//status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, statusCode_OK);
		
		//status Line
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusLine, statusLine_200);
		
		//header - contentType
		String contentType = response.getContentType();
		Assert.assertEquals(contentType, contentType_expected);
		
		//page values
		int page = jp.getInt("page");
		int pageSize = jp.getInt("pageSize");
		int totalPageCount = jp.getInt("totalPageCount");
		Assert.assertEquals(page, page_expected);
		Assert.assertEquals(pageSize, pageSize_expected);
		Assert.assertEquals(totalPageCount, totalPageCount_expected);
		
		//models 
		int totalModels = models.size();
		int totalModelsKeys = models.keySet().size();
		int totalModelsValues = models.values().size();
		Assert.assertEquals(totalModels, Integer.parseInt(countOfModels));
		Assert.assertEquals(totalModelsKeys, Integer.parseInt(keys));
		Assert.assertEquals(totalModelsValues, Integer.parseInt(values));
		
		// models keys and values comparison
		Set<String> actualKeys = models.keySet();
		Set<String> actualValues = new HashSet<String>(models.values());
		Assert.assertEquals(actualKeys, expectedKeys);
		Assert.assertEquals(actualValues, expectedValues);			
	}

	
	@DataProvider(name="MainTypesData")
	public Object[][] createdata()throws Exception
    {	
        Object[][] obj =MultipleDataProvider.getDataFromDataprovider("MultipleData.xlsx", "Data_MainTypes") ;
        return obj;              
    }


}
